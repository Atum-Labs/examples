# Idempotency

Send the same request twice — a retry, a timeout, a network blip — and it should
count once, not twice, and give you the **same** answer both times. On a payment
that means you are charged once. The key to both properties is the `request_id`
you send.

One contract covers every write endpoint. Today that is `submitPayment` and
`createQuoteRequest`; they use the same key, reject the same misuse the same way,
and report a replay the same way, so what you learn on one applies to the other.
Where an endpoint genuinely differs it is called out inline.

## Using the SDK

With `@atumlabs/payment-gateway-client` this is automatic. Pass a stable
`request_id` and reuse it on retry. `request_id` is required on the payment path
(`preparePaymentRequest`); the SDK derives the on-chain deposit nonce
deterministically from it, so both guarantees below line up on their own. You
never manage nonces — `request_id` is the only value you control.

Reuse the same `request_id` across attempts of the same logical request. Use a
fresh `request_id` only when you genuinely mean a new one.

Both builders require it: `preparePaymentRequest` and `prepareQuoteRequest` each
take `requestId` explicitly, and neither invents one. That is deliberate — an id
the library chose for you is an id you cannot reuse on a retry, so the retry would
create a second payment or open a second batch rather than recovering the first.

The CLIs are the exception, because a command invocation is a one-shot request:
`send-payment` and `request-quote` generate an id when `--request-id` is omitted
and print it back, so you can re-run with `--request-id <id>` to retry the same
one. A bare re-run, with no `--request-id`, is a **separate** payment or batch.

## The two guarantees

### 1. Gateway dedup — every write endpoint, every caller

The gateway records your `request_id` (scoped to your source account and signing
identity). If the same `request_id` arrives again, the gateway returns what it
created the first time and creates nothing new:

| Endpoint | A repeat returns | And does not |
| -- | -- | -- |
| `submitPayment` | the original payment — same `payment_id`, status and receipt | create a second payment or broadcast a second deposit |
| `createQuoteRequest` | the original batch — same `quote_request_id` and its quotes | open a second batch or re-broadcast to settlement agents |

This holds whether you use the SDK or call the API directly, as long as you send a
stable `request_id` and reuse it on retry.

"The same request" is the one condition: an id re-used for *different* economics
is rejected rather than replayed. See
[Reusing an id for different terms is rejected](#reusing-an-id-for-different-terms-is-rejected).

### 2. On-chain single-settlement — payments only, enforced by the blockchain

This second guarantee applies where funds move, which today means `submitPayment`.
A quote-request authorizes no spend — it carries no `sender_auth` and no deposit
nonce — so guarantee 1 is the whole mechanism there. Nothing is charged either
way; what a retry protects on that endpoint is your ability to find the batch
again.

Each deposit authorization carries a nonce, and the chain guarantees a given
nonce can settle at most once. This ties your retries together on-chain **only
if** each retry carries the **same** nonce. The SDK derives that nonce from your
`request_id`, so retries reuse it automatically. A direct caller sets the nonce
themselves in the signed permit.

A changing `request_id` defeats both guarantees, because each attempt is then
treated as a different request — keep it stable and reuse it on retry.

## Reusing an id for different terms is rejected

One `request_id` identifies one payment, or one quote-request batch, so it cannot
be pointed at different economics. Re-submit an id you have already used with a
changed amount, token, account or destination and the gateway answers **`409`**
with `IDEMPOTENCY_TERMS_MISMATCH` rather than acting on it, and rather than
quietly serving you the original.

What counts as "different economics" is who pays, who receives, in which assets,
and for how much — the terms that decide where the money goes. Change any of them
and you get the `409`; the error's `message` names the category that differed. A
genuinely different request needs a new `request_id`, which is what the error is
telling you.

On a quote-request the `409` is doing the same job one step earlier: without it
you would silently receive the batch you opened *earlier*, whose quotes price the
corridor you asked for then — and awarding one of those settles a payment on that
corridor, not the one you meant.

Anything outside that list is taken from what already exists, and the value you
sent is not applied. So a re-submission is not a way to amend something in flight;
it is a way to ask for the one you already made.

### Deadlines and the signature are exempt

Two things you may freely change on a re-submission, because neither identifies
the request:

- **Deadlines.** Re-send the original bytes unchanged and the deadlines will
  usually have expired by then: `quote_deadline` is short — it bounds the auction
  on a payment and the collection window on a quote-request — and either endpoint
  can take longer than that to answer. An expired deadline on a re-submission is
  **not** an error; the request resolves onto what already exists, so nothing is
  scheduled against it.
- **The signature.** Re-signing is fine. So is re-sending the original signature.

Which means both retry styles work: keep the exact bytes from the first attempt,
or rebuild and re-sign. What must not change is the `request_id`.

One consequence is specific to quote-requests: **the collection window belongs to
the batch, not to your request.** Asking again with a later `quote_deadline` does
not extend a window already open. The `quote_deadline` you get back is the
batch's own, and `status` tells you whether collection is still running. This is
the one place where a re-submission returns something that may not match what you
just sent — by design, because the response has to describe the batch you
actually received.

## Telling a retry from a first attempt

`idempotent_replay` is `true` when you have been handed something that already
existed, and `false` when this request created it. Every write response carries
it — `PaymentResponse`, `QuoteRequestResponse` and `QuoteRequestAccepted`. Read it
if you need to distinguish "this went through just now" from "this was already
there" — for logging, for reconciliation, or to avoid double-counting a
conversion.

It is always present, so `false` means `false`. A response missing the field
altogether is from a gateway predating it.

## Reading the outcome (payments)

`status` is on every payment response, and the three endings mean different things for a
retry:

| `status`               | What it means                     | What to do                                             |
| ---------------------- | --------------------------------- | ------------------------------------------------------ |
| `completed`            | Settled.                          | Nothing. `fulfillment_confirmation` carries the proof. |
| `pending`              | Accepted, still settling.         | Re-submit the **same** `request_id`, or read the status endpoint. Do not start a new payment. |
| `failed` / `cancelled` | Terminal — it can never complete. | A fresh attempt needs a **new** `request_id`.          |

`pending` is not success. Cross-chain settlement can outrun the gateway's
synchronous window, so a payment that has been accepted may still have no result
when you get your response.

A terminal failure **keeps** its `request_id`. Re-submitting that id returns the
same failed payment for good, which is why recovering from one means minting a
new id — the opposite of what a pending payment needs. Getting these two the
wrong way round is how a caller either pays twice or waits for something that
will never happen.

### How to learn the outcome

Either works, and you can mix them:

- **Poll `GET /v1/payments/{payment_id}/status`** — cheapest once you hold a
  `payment_id`. This is what the `payment-status` CLI does, and what
  `send-payment --wait` does after submitting.
- **Re-submit the same request** — idempotent, and it returns the payment's
  current state. Useful when you would rather not track `payment_id`, or when the
  first attempt failed before you learned one.

If you are building a *merchant* that mediates someone else's HTTP request,
prefer having the payer re-attempt over polling inside that request: polling
holds the connection open for the whole settlement window. That constraint is
specific to sitting in the middle of someone else's request, and does not apply
to a backend calling this SDK directly.

## Recovering a lost quote-request response

The rules above are all you need for payments. On `createQuoteRequest` they add up
to one workflow worth spelling out, because it is the reason the endpoint behaves
this way.

If you lose the create response, re-send the request. You get your
`quote_request_id` back and can read the batch's quotes — rather than being told
your `quote_deadline` has expired while holding no id to look the batch up with.
The collection window is short, so by the time you retry it usually *has* expired;
that is exactly the case the deadline exemption exists to cover.

## Chain-specific behavior

The SDK gives you the same guarantee on every chain; the on-chain half works
slightly differently underneath:

- **EVM / Tron:** the on-chain nonce is spent permanently, so guarantee 2 lasts
  indefinitely.
- **Solana:** the on-chain guard covers only a short, bounded window (roughly two
  minutes). Beyond that window the durable protection is guarantee 1 (the
  gateway's `request_id` record). The SDK keeps a rebuild inside the window by
  pinning `issued_at` through its Solana clock reader, so you do not have to.

Either way, a stable `request_id` keeps you safe on every chain.

## A note on addresses

EVM `0x` addresses are case-insensitive, so casing never affects your payment.
Solana and Tron base58 addresses **are** case-sensitive — pass them exactly as
issued.
